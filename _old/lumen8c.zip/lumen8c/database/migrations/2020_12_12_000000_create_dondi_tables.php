<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateLocalitaTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
         
		 
		Schema::create('lookup', function (Blueprint $table) {
			$table->id();
			$table->timestamps();
			$table->string('tag')->index();  // cer, conferimenti,azconf:aziendaconferimeti, 
			//$table->unsignedBigInteger('tag_id')->nullable();
			$table->string('tag_info_1');
			$table->string('tag_info_2');
			$table->string('tag_info_3');
			$table->string('tag_info_4');

		});
		Schema::create('macchine', function (Blueprint $table) {
			$table->id();
			$table->timestamps();
			$table->string('targa')->unique();  
			$table->string('tipo'); 
			$table->string('foto')->nullable();
			$table->timestamps();
		});
		Schema::create('macchine_uso', function (Blueprint $table) {
			$table->id();		// record aperto finche non viene salvato uno scarico
			$table->dateTime('carico_at')->nullable();
			$table->dateTime('scarico_at')->nullable();
			$table->float('carico_km')->unsigned()->nullable();	// quanti km a inizio gita... facoltativo
			$table->float('scarico_km')->unsigned();			// quanti km a fine gita
			$table->float('euro')->unsigned()->nullable();
			$table->float('litri')->unsigned()->nullable();
			$table->timestamps();
		});
		Schema::create('localita', function (Blueprint $table) {
			$table->id();
			$table->timestamps();
			$table->string('localita')->unique();
			$table->string('comune');
			$table->string('cap');
		});
		Schema::create('tipo_impianto', function (Blueprint $table) {
			$table->id();
			$table->timestamps();
			$table->string('tipo')->unique();
		});
		Schema::create('impianti', function (Blueprint $table) {
			$table->id();
			$table->timestamps();
			$table->string('codice')->unique()->index();
			$table->string('nome')->unique();
			$table->unsignedBigInteger('tipo_id')->nullable();
			$table->string('lotto')->default('1');
			$table->unsignedBigInteger('localita_id')->nullable();
			$table->foreign('tipo_id')->references('id')->on('tipo_impianto')->onDelete('SET NULL');
			$table->foreign('localita_id')->references('id')->on('localita')->onDelete('SET NULL');
		});
		
		Schema::create('foto', function (Blueprint $table) {
			$table->id();
			$table->timestamps();
			$table->unsignedBigInteger('user_id');
			$table->string('foto');
			$table->foreign('user_id')->references('id')->on('users')->onDelete('SET NULL');
		});
		
		Schema::create('impianti_foto', function (Blueprint $table) {
			$table->id();
			$table->timestamps();
			$table->unsignedBigInteger('impianto_id');
			$table->unsignedBigInteger('foto_id');
			$table->foreign('impianto_id')->references('id')->on('impianti')->onDelete('SET NULL');
			$table->foreign('foto_id')->references('id')->on('foto')->onDelete('SET NULL');

		});

		Schema::create('tipo_attivita', function (Blueprint $table) {
			$table->id();
			$table->timestamps();
			$table->string('tipo')->unique();  // ordinaria,straordinaria
		});
		Schema::create('attivita', function (Blueprint $table) {
			$table->id();
			$table->timestamps();
			$table->string('attivita');
			$table->unsignedBigInteger('tipo_impianto_id')->nullable();  //depuratore,imhoff
			$table->unsignedBigInteger('tipo_attivita_id')->nullable();  //ordinaria,straordinaria
			$table->unsignedTinyInteger('libero')->default(0);  // arriva da campo libero
			$table->foreign('tipo_impianto_id')->references('id')->on('tipo_impianto')->onDelete('SET NULL');
			$table->foreign('tipo_attivita_id')->references('id')->on('tipo_attivita')->onDelete('SET NULL');
		});
		Schema::create('attivita_impianti', function (Blueprint $table) {
			$table->id();
			$table->timestamps();
			$table->date('user_at')->nullable();                		// quando
			$table->unsignedBigInteger('user_id'); 					// chi ha fatto
			$table->unsignedBigInteger('attivita_id');          		// (cosa) quale attivita      
			$table->unsignedBigInteger('impianto_id')->nullable();  	// (dove) su quale impianto
			$table->foreign('user_id')->references('id')->on('users')->onDelete('SET NULL');
			$table->foreign('attivita_id')->references('id')->on('attivita')->onDelete('SET NULL');           
			$table->foreign('impianto_id')->references('id')->on('impianti')->onDelete('SET NULL');
		});
		
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
		Schema::disableForeignKeyConstraints();
		Schema::dropIfExists('localita');
		Schema::dropIfExists('tipo_impianto');
		Schema::dropIfExists('impianti');
		Schema::dropIfExists('tipo_attivita');
		Schema::dropIfExists('attivita');
		Schema::dropIfExists('attivita_impianti');
    }
}
