<?php

namespace App\Http\Controllers;

use App\Models\Author;
use Illuminate\Http\Request;

class AuthorController extends Controller
{

    public function showAll()
    {
        return response()->json(Author::all());
    }

    public function showOne($id)
    {
        return response()->json(Author::find($id));
    }

    public function create(Request $request)
    {
		$this->validate($request, Author::$rules);
		
		$twitter = $request->input( 'twitter' );	
		$twitter = isset($twitter) ? '' : app('hash')->make($twitter);
		$request->merge([
			'twitter' => $twitter,
			'github'=>'12345user'
		]);
		
        $author = Author::create($request->all());

        return response()->json($author, 201);
    }

    public function update($id, Request $request)
    {
        $author = Author::findOrFail($id);
		
		$request->merge(['github'=>'12345user']);
		$data = $request->all();
		if(isset($data['twitter'])) $data['twitter'] = app('hash')->make($data['twitter']);
		
        $author->update($data);

        return response()->json($author, 200);
    }

    public function delete($id)
    {
        Author::findOrFail($id)->delete();
        return response('Deleted Successfully', 200);
    }
}