<p>Buongiorno {{$name}}</p>
<p>Questa la tua password per accedere al sito <a href="{{$app_url}}">{{$app_name}}</a>:</p>
<h1>{{$password}}</h1>
<p>
Saluti,<br>
l'Amministratore
</p>