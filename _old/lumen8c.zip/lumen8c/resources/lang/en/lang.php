<?php

return [ 
	'welcome' => 'Benvenuto',
	'title'=> 'Laravel Localization',
	'message'=> [
		'default' => "Let's learn Laravel Localization",
		'welcome' => "Benvenuti in lumen",
	],
]
?>