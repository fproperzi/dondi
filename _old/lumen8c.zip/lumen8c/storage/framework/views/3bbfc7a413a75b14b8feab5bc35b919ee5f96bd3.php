<p>Hello recipient,</p>
<p>This is a sample email. Please do not reply!</p>
<p>
Regards,<br>
Sender.
</p><?php /**PATH C:\xampp\htdocs\dondi\lumen8c\resources\views/my-email.blade.php ENDPATH**/ ?>