<p>Buongiorno <?php echo e($name); ?></p>
<p>Questa la tua password per accedere al sito <a href="<?php echo e($app_url); ?>"><?php echo e($app_name); ?></a>:</p>
<h1><?php echo e($password); ?></h1>
<p>
Saluti,<br>
l'Amministratore
</p><?php /**PATH C:\xampp\htdocs\dondi\lumen8c\resources\views/email_recover_password.blade.php ENDPATH**/ ?>