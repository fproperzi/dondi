<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{
	public function __construct()
    {
        //$this->middleware('auth');
    }

    public function showAll()
    {
        return response()->json(User::all());
    }

    public function showOne($id)
    {
        return response()->json(User::find($id));
    }
	
    public function create(Request $request)
    {
        //validate incoming request 
        $this->validate($request, [
            'name'		=> 'required|string',
            'email' 	=> 'required|email|unique:users',
            'password' 	=> 'required|confirmed',
        ]);

        try {
			$data = $request->all();
            $password = $request->input('password');		
			$request->merge(['password' => app('hash')->make($password)]);	
			
			$user = User::create($request->all());

			return response()->json($user, 201);


        } catch (\Exception $e) {

            return response()->json([
				'message' => 'User Registration Failed!',
				'post' =>  print_r($data,true),
				'exception' => print_r($e,true)
			
			], 409);
        }

    }

    public function update($id, Request $request)
    {
		$user = User::findOrFail($id);
		
        $this->validate($request, [
            'name'		=> 'required|string',
            'email' 	=> 'required|email|unique:users',
            'password' 	=> 'confirmed',						// se non la tocchi rimane la vecchia
        ]);
		
		$password = $request->input('password');
		if(isset($password)) $request->merge(['password' => app('hash')->make($password)]);
		
        $user->update($request->all());

        return response()->json($user, 200);
    }
	
	public function delete($id)
    {
        User::findOrFail($id)->delete();
        return response('Deleted Successfully', 200);
    }
	

}