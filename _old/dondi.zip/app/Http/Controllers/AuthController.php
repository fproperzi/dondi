<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    
	
	public function login(Request $request)
    {
        $this->validate($request, [
            'email'    => 'required|email',
            'password' => 'required|string',
        ]);

        $credentials = $request->only(['email', 'password']);
		
		$t = auth()->attempt($credentials);
		//return response()->json($t, 201);

        if (! $token = Auth::attempt($credentials)) {			
            return response()->json([
                'message' => 'Unauthorized'
            ], 401);
        }
        return $this->respondWithToken($token);
    }
	
	
	public function logout()
    {
        auth()->logout();

        return response()->json(['message' => 'Successfully logged out']);
    }
	
	public function refresh()
    {
        return $this->respondWithToken(auth()->refresh());
    }

	public function profile()
    {
        return response()->json(['user' => Auth::user()], 200);
    }

}